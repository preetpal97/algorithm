import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btoa',
  templateUrl: './btoa.component.html',
  styleUrls: ['./btoa.component.css']
})
export class BtoaComponent implements OnInit {
  
  constructor() { }
  decimal:number;
  ascii:string;
  
  ngOnInit() {
  }
  binarytoascii(binaryNumber:string){
    if(binaryNumber.match("[2-9]"))
    {
      this.ascii="NaN";
    }else{
      this.decimal=parseInt(binaryNumber, 2);
      console.log(this.decimal)
      this.ascii=String.fromCharCode(this.decimal)
    }
    
  }
  
}
