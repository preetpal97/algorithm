import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-htoa',
  templateUrl: './htoa.component.html',
  styleUrls: ['./htoa.component.css']
})
export class HtoaComponent implements OnInit {

  constructor() { }
  decimal:number
  hex:string
  ascii:string
  ngOnInit() {
  }
  hexatoascii(hexaNumber){
    this.decimal=parseInt(hexaNumber, 16);
    this.ascii=String.fromCharCode(this.decimal);
  }
}
