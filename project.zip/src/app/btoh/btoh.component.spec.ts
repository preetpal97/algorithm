import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtohComponent } from './btoh.component';

describe('BtohComponent', () => {
  let component: BtohComponent;
  let fixture: ComponentFixture<BtohComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtohComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtohComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
