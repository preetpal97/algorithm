import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btoh',
  templateUrl: './btoh.component.html',
  styleUrls: ['./btoh.component.css']
})
export class BtohComponent implements OnInit {
  
  constructor() { }
  
  ngOnInit() {
  }
  title = 'calculator';
  
  decimal: number;
  octal:string;
  hexa:string;
  d:number;
  h:number;
col1:any=document.getElementsByClassName("example");
i:number;
content:any;
  func()
  {
 for (this.i =0;this.i < this.col1.length; this.i++) {
   this.col1[this.i].addEventListener("click", function() {
     this.classList.toggle("active");
     this.content = this.nextElementSibling;
     if (this.content.style.display === "block") {
      this.content.style.display = "none";
    } else {
      this.content.style.display = "block";
    }
   });}
  }
  binarytohexa(binaryNumber:string){
    if(binaryNumber.match("[2-9]"))
  {
    this.hexa="NaN";
  }else{
    this.h=parseInt(binaryNumber, 2);
    this.hexa=(this.h).toString(16);
  }
}
}



