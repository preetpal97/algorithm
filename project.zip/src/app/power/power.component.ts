import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-power',
  templateUrl: './power.component.html',
  styleUrls: ['./power.component.css']
})
export class PowerComponent implements OnInit {
  milliwatts:number
  watts:number
  kilowatts:number
  megawatts:number
  gigawatts:number
  decibelwatts:number
  horsepower:number
  BTU:number

  constructor() { }

  ngOnInit() {
  }
  ConvertMMW(milliwatts1:number)
  {
    this.milliwatts=milliwatts1
    this.watts=milliwatts1/1000
    this.kilowatts=milliwatts1/1000000
    this.megawatts=milliwatts1/1000000000
    this.gigawatts=milliwatts1/1000000000000
    this.decibelwatts=10*Math.log(milliwatts1)*Math.LOG10E-30
    this.horsepower=milliwatts1*1e-3/745.699872
    this.BTU=milliwatts1*1e-3/0.29307107

  }
  ConvertW(watts1:number)
  {
    this.milliwatts=watts1*1000
    this.watts=watts1
    this.kilowatts=watts1
    this.megawatts=watts1
    this.gigawatts=watts1
    this.decibelwatts=10*Math.log(watts1)*Math.LOG10E
    this.horsepower=watts1/745.699872
    this.BTU=watts1/0.29307107
 }
 ConvertKW(kilowatts1:number)
 {
  this.milliwatts=kilowatts1*1000000
  this.watts=kilowatts1*1000
  this.kilowatts=kilowatts1
  this.megawatts=kilowatts1/1000
  this.gigawatts=kilowatts1/1000000
  this.decibelwatts=10*Math.log(kilowatts1*1e3)*Math.LOG10E
  this.horsepower=kilowatts1*1e3/745.699872
  this.BTU=kilowatts1*1e3/0.29307107

 }
 ConvertMW(megawatts1:number)
 {
  this.milliwatts=megawatts1*1000000000
  this.watts=megawatts1*1000000
  this.kilowatts=megawatts1*1000
  this.megawatts=megawatts1
  this.gigawatts=megawatts1/1000
  this.decibelwatts=10*Math.log(megawatts1*1e6)*Math.LOG10E
  this.horsepower=megawatts1*1e6/745.699872
  this.BTU=megawatts1*1e6/0.29307107
 }
 ConvertGw(gigawatts1:number)
 {
  this.milliwatts=gigawatts1*1000000000000
  this.watts=gigawatts1*1000000000
  this.kilowatts=gigawatts1*1000000
  this.megawatts=gigawatts1*1000
  this.gigawatts=gigawatts1
  this.decibelwatts=10*Math.log(gigawatts1*1e9)*Math.LOG10E
  this.horsepower=gigawatts1*1e9/745.699872
  this.BTU=gigawatts1*1e9/0.29307107
 }
 ConvertDeW(decibelwatts1:number)
 {
  this.milliwatts=1
  this.watts=decibelwatts1
  this.kilowatts=decibelwatts1
  this.megawatts=decibelwatts1
  this.gigawatts=decibelwatts1
  this.decibelwatts=decibelwatts1
  this.horsepower=decibelwatts1
  this.BTU=decibelwatts1
 }
 ConvertHpW(horsepower1:number)
 {
  this.milliwatts=1
  this.watts=horsepower1
  this.kilowatts=horsepower1
  this.megawatts=horsepower1
  this.gigawatts=horsepower1
  this.decibelwatts=horsepower1
  this.horsepower=horsepower1
  this.BTU=horsepower1
 }
 ConvertBTU(BTU1:number)
 {
  this.milliwatts=1
  this.watts=BTU1
  this.kilowatts=BTU1
  this.megawatts=BTU1
  this.gigawatts=BTU1
  this.decibelwatts=BTU1
  this.horsepower=BTU1
  this.BTU=BTU1
 }
}
