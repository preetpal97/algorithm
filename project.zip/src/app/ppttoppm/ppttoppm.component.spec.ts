import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PpttoppmComponent } from './ppttoppm.component';

describe('PpttoppmComponent', () => {
  let component: PpttoppmComponent;
  let fixture: ComponentFixture<PpttoppmComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PpttoppmComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PpttoppmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
