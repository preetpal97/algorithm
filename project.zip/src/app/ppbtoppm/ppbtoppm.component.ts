import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppbtoppm',
  templateUrl: './ppbtoppm.component.html',
  styleUrls: ['./ppbtoppm.component.css']
})
export class PpbtoppmComponent implements OnInit {
ppm:number;
  constructor() { }

  ngOnInit() {
  }
  ppbtoppm(PPBNumber:number)
  {
    this.ppm=PPBNumber/1000;
  }
}
