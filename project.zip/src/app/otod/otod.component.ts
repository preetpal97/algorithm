import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otod',
  templateUrl: './otod.component.html',
  styleUrls: ['./otod.component.css']
})
export class OtodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title = 'calculator';
  
  x:string;
  y:number;
  z:string;
  l:number;
  m:number;

  octaltodecimal(octalNumber:string){
    this.y=parseInt(octalNumber, 8);
  }


}