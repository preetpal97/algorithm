import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ptof',
  templateUrl: './ptof.component.html',
  styleUrls: ['./ptof.component.css']
})
export class PtofComponent implements OnInit {
n : number;
d : number;
  constructor() { }

  ngOnInit() {

  }
percenttofraction(percent:number){
this.n=percent/100;
this.d=percent/100;
}
}
