import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DtooComponent } from './dtoo.component';

describe('DtooComponent', () => {
  let component: DtooComponent;
  let fixture: ComponentFixture<DtooComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DtooComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DtooComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
