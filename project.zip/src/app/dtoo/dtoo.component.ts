import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dtoo',
  templateUrl: './dtoo.component.html',
  styleUrls: ['./dtoo.component.css']
})
export class DtooComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;
  decimaltooctal(decimalNumber:string){
    this.v=parseInt(decimalNumber,10);  
    this.q=(this.v).toString(8);
  }


}
