import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtohComponent } from './otoh.component';

describe('OtohComponent', () => {
  let component: OtohComponent;
  let fixture: ComponentFixture<OtohComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtohComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtohComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
