import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DtobComponent } from './dtob.component';

describe('DtobComponent', () => {
  let component: DtobComponent;
  let fixture: ComponentFixture<DtobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DtobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DtobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
