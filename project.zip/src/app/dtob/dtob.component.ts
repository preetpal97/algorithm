import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dtob',
  templateUrl: './dtob.component.html',
  styleUrls: ['./dtob.component.css']
})
export class DtobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;
  decimaltobinary(decimalNumber:string){
    this.u=parseInt(decimalNumber,10);  
    this.p=(this.u).toString(2);
  }



}
