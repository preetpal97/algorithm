import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DtorComponent } from './dtor.component';

describe('DtorComponent', () => {
  let component: DtorComponent;
  let fixture: ComponentFixture<DtorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DtorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DtorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
