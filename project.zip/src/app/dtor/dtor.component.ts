import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dtor',
  templateUrl: './dtor.component.html',
  styleUrls: ['./dtor.component.css']
})
export class DtorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
