import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtobComponent } from './htob.component';

describe('HtobComponent', () => {
  let component: HtobComponent;
  let fixture: ComponentFixture<HtobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
