import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-htob',
  templateUrl: './htob.component.html',
  styleUrls: ['./htob.component.css']
})
export class HtobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  a:string;
  b:string;
  c:number;
  e:number;
  f:number;


  hexatobinary(hexaNumber:string){
    
    this.f=parseInt(hexaNumber, 16);
    this.a=(this.f).toString(2);
  }

}
