import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ftod',
  templateUrl: './ftod.component.html',
  styleUrls: ['./ftod.component.css']
})
export class FtodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  v:number;
  Fractiontodecimal(Numerator:number,Denominator:number)
  {
    this.v=(Numerator/Denominator);

  }

}
