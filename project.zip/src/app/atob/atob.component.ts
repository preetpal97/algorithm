import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-atob',
  templateUrl: './atob.component.html',
  styleUrls: ['./atob.component.css']
})
export class AtobComponent implements OnInit {
  dec:string
  ascii:string
  decimal:number
  binaryy:string
  constructor() { }

  ngOnInit() {
    // var a="A"
    // console.log(a.charCodeAt(0))

  }
  asciitobinary(ascii){
    this.dec=ascii.charCodeAt(0);
    this.decimal=parseInt(this.dec,10);
    this.binaryy=this.decimal.toString(2)
  }
}
