import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppmtopercent',
  templateUrl: './ppmtopercent.component.html',
  styleUrls: ['./ppmtopercent.component.css']
})
export class PpmtopercentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  //ppm:number;
  percent:string;
  ppmtopercent(PPMNumber:number)
  {
 this.percent=PPMNumber/10000+'%';
  }


}
