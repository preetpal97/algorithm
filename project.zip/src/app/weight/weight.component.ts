import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weight',
  templateUrl: './weight.component.html',
  styleUrls: ['./weight.component.css']
})
export class WeightComponent implements OnInit {
  Metrictons:number
  Kilograms:number
  
  Grams:number
  Milligrams:number
  Micrograms:number
  Stones:number
  Pounds:number
  Ounces:number
  constructor() { }

  ngOnInit() {
  }
  ConvertMet(Metrictons1:number)
  {
    this.Metrictons=Metrictons1;
    this.Kilograms=Metrictons1*1000;
    this.Grams=Metrictons1*1000000
    this.Milligrams=Metrictons1*1000000000
    this.Micrograms=Metrictons1*1000000000000
    this.Stones=Metrictons1*1000/0.45359237/14
    this.Pounds=Metrictons1*1000/0.45359237
    this.Ounces=Metrictons1*1000/0.45359237*16
  }
  ConvertKg(Kilograms1:number)
  {
    this.Metrictons=Kilograms1/1000
    this.Kilograms=Kilograms1
    this.Grams=Kilograms1*1000
    this.Milligrams=Kilograms1*1000000
    this.Micrograms=Kilograms1*1000000000
    this.Stones=Kilograms1/0.45359237/14
    this.Pounds=Kilograms1/0.45359237
    this.Ounces=Kilograms1/0.45359237*16

  }
  ConvertGra(Grams1:number)
  {
    this.Metrictons=Grams1/1000000;
    this.Kilograms=Grams1/1000
    this.Grams=Grams1
    this.Milligrams=Grams1*1000
    this.Micrograms=Grams1*1000000
    this.Stones=Grams1/1000/0.45359237/14
    this.Pounds=Grams1/1000/0.45359237
    this.Ounces=Grams1/1000/0.45359237*16
  }
ConvertMig(Milligrams1:number)
{this.Metrictons=Milligrams1/1000000000;
  this.Kilograms=Milligrams1/1000000
  this.Grams=Milligrams1/1000
  this.Milligrams=Milligrams1
  this.Micrograms=Milligrams1*1000
  this.Stones=Milligrams1/1000000/0.45359237/14
  this.Pounds=Milligrams1/1000000/0.45359237
  this.Ounces=Milligrams1/1000000/0.45359237*16

}
ConvertMcg(Micrograms1:number)
{
  this.Metrictons=Micrograms1/1000000000000;
  this.Kilograms=Micrograms1/1000000000;
  this.Grams=Micrograms1/1000000
  this.Milligrams=Micrograms1/1000
  this.Micrograms=Micrograms1
  this.Stones=Micrograms1/1000000000/0.45359237/14
  this.Pounds=Micrograms1/1000000000/0.45359237
  this.Ounces=Micrograms1/1000000000/0.45359237*16
}
ConvertSt(Stones1:number)
{
  this.Metrictons=Stones1*14*0.45359237/1000;
  this.Kilograms=Stones1*14*0.45359237
  this.Grams=Stones1*14*0.45359237*1000
  this.Milligrams=Stones1*14*0.45359237*1000000
  this.Micrograms=Stones1*14*0.45359237*1000000000
  this.Stones=Stones1
  this.Pounds=Stones1*14
  this.Ounces=Stones1*14*16
}
ConvertP(Pounds1:number)
{
  this.Metrictons=Pounds1*0.45359237/1000;
  this.Kilograms=Pounds1*0.45359237
  this.Grams=Pounds1*0.45359237*1000
  this.Milligrams=Pounds1*0.45359237*1000000
  this.Micrograms=Pounds1*0.45359237*1000000000
  this.Stones=Pounds1/14
  this.Pounds=Pounds1
  this.Ounces=Pounds1*16
}
ConvertO(Ounces1:number)
{
  this.Metrictons=Ounces1/16*0.45359237*1000
  this.Kilograms=Ounces1/16*0.45359237
  this.Grams=Ounces1/16*0.45359237*1000
  this.Milligrams=Ounces1/16*0.45359237*1000000
  this.Micrograms=Ounces1/16*0.45359237*1000000000
  this.Stones=Ounces1/16/14
  this.Pounds=Ounces1/16
  this.Ounces=Ounces1
}

}
