import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-htod',
  templateUrl: './htod.component.html',
  styleUrls: ['./htod.component.css']
})
export class HtodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  a:string;
  b:string;
  c:number;
  e:number;
  f:number;


  hexatodecimal(hexaNumber:string){
    this.c=parseInt(hexaNumber, 16);
  }


}
