import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dtop',
  templateUrl: './dtop.component.html',
  styleUrls: ['./dtop.component.css']
})
export class DtopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;

  decimaltopercent(decimalNumber:number)
  {
    this.v=decimalNumber*100;

  }
}
