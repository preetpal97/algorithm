import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ac',
  templateUrl: './ac.component.html',
  styleUrls: ['./ac.component.css']
})
export class AcComponent implements OnInit {
  
  constructor() { }
  
  ngOnInit() {
  }
  
  cm:number;
  dm:number;
  ft:number;
  inc:number;
  km:number;
  m:number;
  mi:number;
  mm:number;
  nmi:number;
  yd:number;
  i:string;
  hec:number;
  ac:number;
  
  ConvertCm(cm:number)
  {
    this.cm=cm;
    this.dm=cm*(1/10)**2;
    this.ft=cm*(1/2.54/12)**2;
    this.inc=cm*(1/2.54)**2;
    this.km=cm*(1/100000)**2;
    this.m=cm*(1/100)**2;
    this.mi=cm*(1/160934.4)**2;
    this.mm=cm*(10)**2;
    this.nmi=cm*(1/185200)**2;
    this.yd=cm*(1/2.54/36)**2;
    this.hec=cm/100000000;
    this.ac=cm/4.047e+7;
    
    
  }
  ConvertDm(dm:number)
  {
    this.dm=dm;
    this.cm=dm*(10)**2;
    this.ft=dm*(1/0.254/12)**2
    this.inc=dm*(1/0.254)**2
    this.km=dm*(1/10000)**2
    this.m=dm*(1/10)**2
    this.mi=dm*(1/16093.44)**2
    this.mm=dm*(100)**2
    this.nmi=dm*(1/18520)**2
    this.yd=dm*(1/0.254/36)**2
    this.hec=dm/1000000;
    this.ac=dm/404686;
  }
  ConvertFt(ft:number)
  {
    this.ft=ft;
    this.cm=ft*(30.48)**2;
    this.dm=ft*(3.048)**2;
    this.inc=ft*(12)**2;
    this.km=ft*(3.0480000)**2;
    this.m=ft*(0.3048)**2;
    this.mi=ft*(1/5280)**2;
    this.mm=ft*(304.8)**2;
    this.nmi=ft*(1/185200*2.54*12)**2;
    this.yd=ft*(1/3)**2;
    this.hec=ft/107639;
    this.ac=ft/43560;
    
  }
  ConvertIn(inc:number)
  {
    this.ft=inc*(1/12)**2;
    this.cm=inc*(25.4)**2;
    this.dm=inc*(0.254)**2;
    this.inc=inc;
    this.km=inc*(2.5400000)**2;
    this.m=inc*(0.02548)**2;
    this.mi=inc*(1/63360)**2;
    this.mm=inc*(25.4)**2;
    this.nmi=inc*(1/185200*2.54)**2;
    this.yd=inc*(1/36)**2;
    this.hec=inc/1.55e+7;
    this.ac=inc/6.273e+6;
  }
  
  ConvertKm(km:number)
  {
    this.cm=km*(100000)**2;
    this.dm=km*(1/10000)**2;
    this.ft=km*(1/2.5400000/12)**2;
    this.inc=km*(1/2.5400000)**2;
    this.km=km
    this.m=km*(1/1000)**2;
    this.mi=km*(1/1.609344)**2;
    this.mm=km*(1000000)**2;
    this.nmi=km*(1/1.852)**2;
    this.yd=km*(1/2.5400000/36)**2;
    this.hec=km*100;
    this.ac=km*247.105
    
  }
  ConvertM(m:number)
  {
    this.cm=m*(100)**2;
    this.dm=m*(1/10)**2;
    this.ft=m*(1/0.0254/12)**2;
    this.inc=m*(1/0.0254)**2;
    this.km=m*(1000)**2
    this.m=m
    this.mi=m*(1/1609.344)**2;
    this.mm=m*(1000)**2;
    this.nmi=m*(1/1852)**2;
    this.yd=m*(1/0.0254/36)**2;
    this.hec=m/10000
    this.ac=m/4046.86
  }
  ConvertMi(mi:number)
  {
    this.cm=mi*(160934.4)**2;
    this.dm=mi*(16093.44)**2;
    this.ft=mi*(5280)**2;
    this.inc=mi*(63360)**2;
    this.km=mi*(1.609344)**2
    this.m=mi*(1609.344)**2
    this.mi=mi;
    this.mm=mi*(1609344)**2;
    this.nmi=mi*(1609.344/1852)**2;
    this.yd=mi*(1760)**2;
    this.hec=mi*258.99;
    this.ac=mi/0.0015625;
  }
  ConvertMm(mm:number)
  {
    this.cm=mm*(1/10)**2;
    this.dm=mm*(1/100)**2;
    this.ft=mm*(1/25.4/12)**2;
    this.inc=mm*(1/25.4)**2;
    this.km=mm*(1/1000000)**2
    this.m=mm*(1/1000)**2
    this.mi=mm*(1/1609344)**2;
    this.mm=mm;
    this.nmi=mm*(1/1852000)**2;
    this.yd=mm*(1/25.4/36)**2;
    this.hec=mm/10000000000;
    this.ac=mm/4.047e+9;
    
  }
  ConvertNMi(nmi:number)
  {
    this.cm=nmi*(185200)**2;
    this.dm=nmi*(18520)**2;
    this.ft=nmi*(1852/0.0254/1)**2;
    this.inc=nmi*(1852/0.0254)**2;
    this.km=nmi*(1.852)**2
    this.m=nmi*(1852)**2
    this.mi=nmi*(1852/1609.344)**2;
    this.mm=nmi*(1852000)**2;
    this.nmi=nmi;
    this.yd=nmi*(1852/0.0254/36)**2;
    this.ac=nmi*847.548
    this.hec=nmi*342.99
  }
  ConvertYd(yd:number)
  {
    this.cm=yd*(2.54*36)**2;
    this.dm=yd*(0.254*36)**2;
    this.ft=yd*(3)**2;
    this.inc=yd*(36)**2;
    this.km=yd*(2.5400000*36)**2
    this.m=yd*(0.0254*36)**2
    this.mi=yd*(1/5280*3)**2;
    this.mm=yd*(25.4*36)**2;
    this.nmi=yd*(1/185200*2.54*36)**2;
    this.yd=yd;
    this.ac=yd/4840
    this.hec=yd/11959.9
  }
  ConvertHec(hec:number)
  {
    this.cm=hec*100000000;
    this.dm=hec*1000000;
    this.ft=hec*107639;
    this.inc=hec*1.55e+7;
    this.km=hec/100
    this.m=hec*10000
    this.mi=hec/258.99;
    this.mm=hec*10000000000;
    this.nmi=hec*0.00291553;
    this.yd=hec/11959.9;
    this.ac=hec*2.47105;
    this.hec=hec;
    
  }
  ConvertAc(ac:number)
  {
    this.cm=ac*4.047e+7;
    this.dm=ac*404686;
    this.ft=ac*43560;
    this.inc=ac*6.273e+6;
    this.km=ac/247.105
    this.m=ac*4046.86
    this.mi=ac*0.0015625;
    this.mm=ac*4.047e+9;
    this.nmi=ac*0.00117987;
    this.yd=ac*4840;
    this.hec=ac/2.47105;
  }
  
}


