import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-temp',
  templateUrl: './temp.component.html',
  styleUrls: ['./temp.component.css']
})
export class TempComponent implements OnInit {
  Celsius:number;
  Fahrenheit:number
  Kelvin:number;
  Rankine:number
 
  constructor() { }

  ngOnInit() {
  }

  ConvertCel(Celsius1:number)
  {
    this.Celsius=Celsius1;
    this.Fahrenheit=(Celsius1*9/5+32);
    this.Kelvin=((Celsius1*1)+273.15);
    this.Rankine=(Celsius1*9/5)+491.67;
  }
  ConvertFah(Fahrenheit1:number)
  {
    this.Celsius=(Fahrenheit1-32)*5/9;
    this.Fahrenheit=Fahrenheit1;
    this.Kelvin=((Fahrenheit1-32)*5/9)+273.15;
    this.Rankine=(Fahrenheit1*1)+459.67;

  }
  Convertkel(Kelvin1:number)
  {
    this.Celsius=(Kelvin1-273.15);
    this.Fahrenheit=(Kelvin1*9/5-459.67);
    this.Kelvin=Kelvin1;
    this.Rankine=(Kelvin1*9/5);
  }
  ConvertRan(Rankine1:number)
  {
    this.Celsius=(Rankine1-491.67)*5/9;
    this.Fahrenheit=(Rankine1-459.67);
    this.Kelvin=(Rankine1*5/9);
    this.Rankine=Rankine1;
  }
}
