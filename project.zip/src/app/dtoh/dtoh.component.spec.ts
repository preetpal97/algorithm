import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DtohComponent } from './dtoh.component';

describe('DtohComponent', () => {
  let component: DtohComponent;
  let fixture: ComponentFixture<DtohComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DtohComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DtohComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
