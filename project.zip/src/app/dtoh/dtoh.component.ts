import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dtoh',
  templateUrl: './dtoh.component.html',
  styleUrls: ['./dtoh.component.css']
})
export class DtohComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;

  decimaltohexa(decimalNumber:string){
    this.w=parseInt(decimalNumber,10);  
    this.r=(this.w).toString(16);
  }


}
