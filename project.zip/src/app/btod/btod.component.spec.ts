import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtodComponent } from './btod.component';

describe('BtodComponent', () => {
  let component: BtodComponent;
  let fixture: ComponentFixture<BtodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
