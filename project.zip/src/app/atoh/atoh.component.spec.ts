import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtohComponent } from './atoh.component';

describe('AtohComponent', () => {
  let component: AtohComponent;
  let fixture: ComponentFixture<AtohComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtohComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtohComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
