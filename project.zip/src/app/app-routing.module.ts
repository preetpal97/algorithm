import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddComponent } from './add/add.component';

import { OctalComponent } from './octal/octal.component';
import { BtohComponent } from './btoh/btoh.component';

import { BtoaComponent } from './btoa/btoa.component';
import { BtodComponent } from './btod/btod.component';
import { BtooComponent } from './btoo/btoo.component';

import { OtodComponent } from './otod/otod.component';

import { AtobComponent } from './atob/atob.component';
import { AtohComponent } from './atoh/atoh.component';

import { HtoaComponent } from './htoa/htoa.component';
import { HtobComponent } from './htob/htob.component';
import { HtodComponent } from './htod/htod.component';

import { DtohComponent } from './dtoh/dtoh.component';
import { DtooComponent } from './dtoo/dtoo.component';
import { DtobComponent } from './dtob/dtob.component';
import { DtopComponent } from './dtop/dtop.component';

import { PpmtopercentComponent } from './ppmtopercent/ppmtopercent.component';
import { PpmtoppbComponent } from './ppmtoppb/ppmtoppb.component';
import { PpmtopptComponent } from './ppmtoppt/ppmtoppt.component';
import { PpbtoppmComponent } from './ppbtoppm/ppbtoppm.component';
import { PpttoppmComponent } from './ppttoppm/ppttoppm.component';
import { RomanComponent } from './roman/roman.component';
import { DtorComponent } from './dtor/dtor.component';
import { MathsComponent } from './maths/maths.component';
import { FractionComponent } from './fraction/fraction.component';
import { PercentComponent } from './percent/percent.component';
import { FtopComponent } from './ftop/ftop.component';
import { FtodComponent } from './ftod/ftod.component';
import { PtofComponent } from './ptof/ptof.component';
import { PtopComponent } from './ptop/ptop.component';
import { ScientificComponent } from './scientific/scientific.component';
import { LcComponent } from './lc/lc.component';
import { AcComponent } from './ac/ac.component';
import { VcComponent } from './vc/vc.component';
import { OtobComponent } from './otob/otob.component';
import { OtohComponent } from './otoh/otoh.component';
import { TempComponent } from './temp/temp.component';
import { WeightComponent } from './weight/weight.component';
import { FrequencyComponent } from './frequency/frequency.component';
import { PowerComponent } from './power/power.component';
const routes: Routes = [
  {
    path:'update', component:AddComponent
  },
 
  {
    path:'octal', component:OctalComponent
  },
  {
path:'roman',component:RomanComponent
  },
  {
    path:'btoh', component:BtohComponent
  },
  {
    path:'btoa',component:BtoaComponent
  },
  {
    path:'btod',component:BtodComponent
  },
  {
    path:'btoo',component:BtooComponent
  },
  {
    path:'otod',component:OtodComponent
  },
  {
    path:'atob',component:AtobComponent
  },
  {
    path:'atoh',component:AtohComponent
  },
  {
    path:'htoa',component:HtoaComponent
  },
  {
    path:'htob',component:HtobComponent
  },
  {
    path:'htod',component:HtodComponent
  },
  {
    path:'dtoh',component:DtohComponent
  },
  {
    path:'dtoo',component:DtooComponent
  },
  {
    path:'dtob',component:DtobComponent
  },
  {
    path:'dtop',component:DtopComponent
  },
  {
    path:'ppmtopercent',component:PpmtopercentComponent
  },
  {
    path:'ppmtoppb',component:PpmtoppbComponent
  },
  {
    path:'ppmtoppt',component:PpmtopptComponent
  },
  {
    path:'ppbtoppm',component:PpbtoppmComponent
  },
  {
    path:'ppttoppm',component:PpttoppmComponent
  },
  {
    path:'dateToRoman',component:DtorComponent
  },
  {
    path:'math',component:MathsComponent
  }
  ,
  {
    path:'fraction',component:FractionComponent
  },
  {
    path:'percent',component:PercentComponent
  }
  ,
  {
    path:'ftop',component:FtopComponent
  },
  {
    path:'ftod',component:FtodComponent
  }
  ,
  {
    path:'ptop',component:PtopComponent
  },
  {
    path:'ptof',component:PtofComponent
  }
  ,
  {
    path:'science',component:ScientificComponent
  }
  ,
  {
    path:'lc',component:LcComponent
  },
  {
    path:'ac',component:AcComponent
  }
  ,
  {
    path:'vc',component:VcComponent
  },
  {
    path:'otob',component:OtobComponent
  },
  {
    path:'otoh',component:OtohComponent
  },
  {
    path:'temperature',component:TempComponent
  },
  {
    path:'weight',component:WeightComponent
  },
  {
    path:'frequency',component:FrequencyComponent
  },
  {
    path:'power',component:PowerComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
