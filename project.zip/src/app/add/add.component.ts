import { Component, OnInit } from '@angular/core';
import { $, $$ } from 'protractor';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  docScroll :  any;
  Flipper :any;
  constructor() { }

  ngOnInit() {
  }
 
}
