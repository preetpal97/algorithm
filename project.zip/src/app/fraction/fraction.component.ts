import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fraction',
  templateUrl: './fraction.component.html',
  styleUrls: ['./fraction.component.css']
})
export class FractionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
