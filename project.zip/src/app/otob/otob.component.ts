import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otob',
  templateUrl: './otob.component.html',
  styleUrls: ['./otob.component.css']
})
export class OtobComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  title = 'calculator';
  
  x:string;
  y:number;
  z:string;
  l:number;
  m:number;

  octaltobinary(octalNumber:string){
    this.l=parseInt(octalNumber, 8);
    this.x=(this.l).toString(2);
  }

}
