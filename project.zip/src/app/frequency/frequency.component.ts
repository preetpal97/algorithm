import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frequency',
  templateUrl: './frequency.component.html',
  styleUrls: ['./frequency.component.css']
})
export class FrequencyComponent implements OnInit {

  hz:number
  khz:number
  mhz:number
  ghz:number
  thz:number


  constructor() { }

  ngOnInit() {
  }
  Converthz(hertz1:number)
  {
    this.hz=hertz1
    this.khz=hertz1/1000
    this.mhz=hertz1/1000000
    this.ghz=hertz1/1000000000
    this.thz=hertz1/1000000000000
  }
  ConvertKHz(kilohertz1:number)
  {
    this.hz=kilohertz1*1000
    this.khz=kilohertz1
    this.mhz=kilohertz1/1000
    this.ghz=kilohertz1/1000000
    this.thz=kilohertz1/1000000000
  }
  ConvertMHz(megahertz1:number)
  {
    this.hz=megahertz1*1000000
    this.khz=megahertz1*1000
    this.mhz=megahertz1
    this.ghz=megahertz1/1000
    this.thz=megahertz1/1000000
  }
  ConvertGHz(gigahertz1:number)
{
  this.hz=gigahertz1*1000000000
  this.khz=gigahertz1*1000000
  this.mhz=gigahertz1*1000
  this.ghz=gigahertz1
  this.thz=gigahertz1/1000
}
ConvertTHz(terahertz1:number)
{
  this.hz=terahertz1*1000000000000
  this.khz=terahertz1*1000000000
  this.mhz=terahertz1*1000000
  this.ghz=terahertz1*1000
  this.thz=terahertz1
}

}
