import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppttoppm',
  templateUrl: './ppttoppm.component.html',
  styleUrls: ['./ppttoppm.component.css']
})
export class PpttoppmComponent implements OnInit {
ppm:number;
  constructor() { }

  ngOnInit() {
  }


ppttoppm(PPTNumber:number)
{
this.ppm=PPTNumber/1000000
}

}
