import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-btod',
  templateUrl: './btod.component.html',
  styleUrls: ['./btod.component.css']
})
export class BtodComponent implements OnInit {
  
  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-1]+")]]
    });
  }
  title = 'calculator';
  
  decimal: number;
  octal:string;
  hexa:string;
  d:number;
  h:number;
  
  
  binarytodecimal(binaryNumber:string)
  {if(binaryNumber.match("[2-9]"))
  {
    this.decimal=parseInt("NaN");
  }
  else{   
    this.decimal=parseInt(binaryNumber,2);
  }
}
}



