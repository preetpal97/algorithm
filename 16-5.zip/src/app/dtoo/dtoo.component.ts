import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-dtoo',
  templateUrl: './dtoo.component.html',
  styleUrls: ['./dtoo.component.css']
})
export class DtooComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-9]+")]]
    });
  }
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;
  decimaltooctal(decimalNumber:string){
    this.v=parseInt(decimalNumber,10);  
    this.q=(this.v).toString(8);
  }


}
