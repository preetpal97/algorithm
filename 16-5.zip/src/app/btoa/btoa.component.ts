import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-btoa',
  templateUrl: './btoa.component.html',
  styleUrls: ['./btoa.component.css']
})
export class BtoaComponent implements OnInit {

  decimal:number;
  ascii:string;
  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-1]+")]]
    });
  }
  binarytoascii(binaryNumber:string){
    if(binaryNumber.match("[2-9]"))
    {
      this.ascii="NaN";
    }else{
      this.decimal=parseInt(binaryNumber, 2);
      console.log(this.decimal)
      this.ascii=String.fromCharCode(this.decimal)
    }
    
  }
  
}
