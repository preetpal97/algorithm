import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtoaComponent } from './btoa.component';

describe('BtoaComponent', () => {
  let component: BtoaComponent;
  let fixture: ComponentFixture<BtoaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtoaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtoaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
