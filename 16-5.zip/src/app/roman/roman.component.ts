import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roman',
  templateUrl: './roman.component.html',
  styleUrls: ['./roman.component.css']
})
export class RomanComponent implements OnInit {
result1:String;
result2:String;
result3:String;
d:number;
m:number;
y:number;
arr:string[];
str1:String;
fv:string;
months:string[];
days:string[];
  constructor() { }

  ngOnInit() {
  }
   romanize (date:Date) {
     this.str1=date.toString();
    this.arr=this.str1.split("-");
    this.y=parseInt(this.arr[0]);
    console.log(this.y)
    
    this.m=parseInt(this.arr[1]);
    this.d=parseInt(this.arr[2]);
    console.log(this.arr);
    this.months=["I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII"];
    this.days=[
      "I","II","III","IV","V","VI","VII","VIII","IX","X","XI","XII","XIII",
      "XIV",
      "XV",
      "XVI",
      "XVII",
      "XVIII",
      "XIX",
      "XX","XXI","XXII","XXIII","XXIV","XXV","XXVI","XXVII","XXVIII","XXIX","XXX","XXXI"]
    if(this.m==1)
    this.result2=this.months[0];
    else if(this.m==2)
    this.result2=this.months[1];
    else if(this.m==3)
    this.result2=this.months[2];
    else if(this.m==4)
    this.result2=this.months[3];
    else if(this.m==5)
    this.result2=this.months[4];
    else if(this.m==6)
    this.result2=this.months[5];
    else if(this.m==7)
    this.result2=this.months[6];
    else if(this.m==8)
    this.result2=this.months[7];
    else if(this.m==9)
    this.result2=this.months[8];
    else if(this.m==10)
    this.result2=this.months[9];
    else if(this.m==11)
    this.result2=this.months[10];
    else if(this.m==12)
    this.result2=this.months[11];
for(let i=1;i<=31;i++)
{
  if(this.d==i)
  this.result1=this.days[i-1];
}

    if (!+this.y)
      return false;
    //   var  digits2 = String(+this.m).split("")
    // var  digits1 = String(+this.y).split("")
    var digits3 = String(+this.y).split(""),
      key = ["","C","CC","CCC","CD","D","DC","DCC","DCCC","CM",
             "","X","XX","XXX","XL","L","LX","LXX","LXXX","XC",
             "","I","II","III","IV","V","VI","VII","VIII","IX"],
      // roman1 = "",
      // roman2="",
      roman3="",
      i = 3;
    while (i--)
    {
      // roman1 = (key[+digits1.pop() + (i * 10)] || "") + roman1;
     // roman2 = (key[+digits2.pop() + (i * 10)] || "") + roman2;
      roman3 = (key[+digits3.pop() + (i * 10)] || "") + roman3;
    }
    // this.result1=Array(+digits1.join("") + 1).join("M") + roman1;
    // this.result2=Array(+digits2.join("") + 1).join("M") + roman2; 
    this.result3=Array(+digits3.join("") + 1).join("M") + roman3;
this.fv=this.result1+"/"+this.result2+"/"+this.result3;
   }

}


