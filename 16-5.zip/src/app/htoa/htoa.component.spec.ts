import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtoaComponent } from './htoa.component';

describe('HtoaComponent', () => {
  let component: HtoaComponent;
  let fixture: ComponentFixture<HtoaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtoaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtoaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
