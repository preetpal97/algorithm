import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-htoa',
  templateUrl: './htoa.component.html',
  styleUrls: ['./htoa.component.css']
})
export class HtoaComponent implements OnInit {

 
  
  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-9A-F]+")]]
    });
  }
  decimal:number
  hex:string
  ascii:string
  hexatoascii(hexaNumber){
    this.decimal=parseInt(hexaNumber, 16);
    this.ascii=String.fromCharCode(this.decimal);
  }
}
