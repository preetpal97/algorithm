import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppmtoppb',
  templateUrl: './ppmtoppb.component.html',
  styleUrls: ['./ppmtoppb.component.css']
})
export class PpmtoppbComponent implements OnInit {
ppb:number;
  constructor() { }

  ngOnInit() {
  }
  ppmtoppb(PPMNumber:number)
  {
this.ppb=PPMNumber*1000;
  }

}
