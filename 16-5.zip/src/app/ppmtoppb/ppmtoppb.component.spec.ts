import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PpmtoppbComponent } from './ppmtoppb.component';

describe('PpmtoppbComponent', () => {
  let component: PpmtoppbComponent;
  let fixture: ComponentFixture<PpmtoppbComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PpmtoppbComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PpmtoppbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
