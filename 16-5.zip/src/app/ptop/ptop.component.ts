import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ptop',
  templateUrl: './ptop.component.html',
  styleUrls: ['./ptop.component.css']
})
export class PtopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  ppm:number;
  percenttoppm(percent:number)
  {
    this.ppm=percent*10000;

  }

}
