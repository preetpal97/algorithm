import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-btoo',
  templateUrl: './btoo.component.html',
  styleUrls: ['./btoo.component.css']
})
export class BtooComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-1]+")]]
    });
  }
  title = 'calculator';
  
  decimal: number;
  octal:string;
  hexa:string;
  d:number;
  h:number;

  binarytooctal(binaryNumber:string){
    if(binaryNumber.match("[2-9]"))
  {
    this.octal=("NaN");
  }
  else{
    this.d=parseInt(binaryNumber, 2);
    this.octal=(this.d).toString(8);
  }
}


}
