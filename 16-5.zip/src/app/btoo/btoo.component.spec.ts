import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtooComponent } from './btoo.component';

describe('BtooComponent', () => {
  let component: BtooComponent;
  let fixture: ComponentFixture<BtooComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtooComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtooComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
