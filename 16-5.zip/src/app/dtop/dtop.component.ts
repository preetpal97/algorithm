import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-dtop',
  templateUrl: './dtop.component.html',
  styleUrls: ['./dtop.component.css']
})
export class DtopComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-9]+")]]
    });
  }
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;

  decimaltopercent(decimalNumber:number)
  {
    this.v=decimalNumber*100;

  }
}
