import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DtopComponent } from './dtop.component';

describe('DtopComponent', () => {
  let component: DtopComponent;
  let fixture: ComponentFixture<DtopComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DtopComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DtopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
