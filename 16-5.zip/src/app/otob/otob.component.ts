import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-otob',
  templateUrl: './otob.component.html',
  styleUrls: ['./otob.component.css']
})
export class OtobComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-7]+")]]
    });
  }

  title = 'calculator';
  
  x:string;
  y:number;
  z:string;
  l:number;
  m:number;

  octaltobinary(octalNumber:string){
    this.l=parseInt(octalNumber, 8);
    this.x=(this.l).toString(2);
  }

}
