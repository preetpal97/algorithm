import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OctalComponent } from './octal.component';

describe('OctalComponent', () => {
  let component: OctalComponent;
  let fixture: ComponentFixture<OctalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OctalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OctalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
