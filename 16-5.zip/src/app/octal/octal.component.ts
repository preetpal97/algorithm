import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-octal',
  templateUrl: './octal.component.html',
  styleUrls: ['./octal.component.css']
})
export class OctalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
