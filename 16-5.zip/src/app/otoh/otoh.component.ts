import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-otoh',
  templateUrl: './otoh.component.html',
  styleUrls: ['./otoh.component.css']
})
export class OtohComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-7]+")]]
    });
  }
  title = 'calculator';
  
  x:string;
  y:number;
  z:string;
  l:number;
  m:number;

  octaltohexa(octalNumber:string){
    this.m=parseInt(octalNumber, 8);
    this.z=(this.m).toString(16);
  }

}
