import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ftop',
  templateUrl: './ftop.component.html',
  styleUrls: ['./ftop.component.css']
})
export class FtopComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;

  Fractiontopercent(Numerator:number,Denominator:number)
  {
    this.v=(Numerator/Denominator)*100;

  }
}
