import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FtodComponent } from './ftod.component';

describe('FtodComponent', () => {
  let component: FtodComponent;
  let fixture: ComponentFixture<FtodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FtodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FtodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
