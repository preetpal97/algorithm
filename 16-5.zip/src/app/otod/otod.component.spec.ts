import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OtodComponent } from './otod.component';

describe('OtodComponent', () => {
  let component: OtodComponent;
  let fixture: ComponentFixture<OtodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OtodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OtodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
