import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
@Component({
  selector: 'app-otod',
  templateUrl: './otod.component.html',
  styleUrls: ['./otod.component.css']
})
export class OtodComponent implements OnInit {
  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-7]+")]]
    });
  }

  title = 'calculator';
  
  x:string;
  y:number;
  z:string;
  l:number;
  m:number;

  octaltodecimal(octalNumber:string){
    this.y=parseInt(octalNumber, 8);
  }


}