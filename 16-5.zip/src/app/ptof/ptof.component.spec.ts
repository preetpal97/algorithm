import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PtofComponent } from './ptof.component';

describe('PtofComponent', () => {
  let component: PtofComponent;
  let fixture: ComponentFixture<PtofComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PtofComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PtofComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
