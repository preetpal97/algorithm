import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-htob',
  templateUrl: './htob.component.html',
  styleUrls: ['./htob.component.css']
})
export class HtobComponent implements OnInit {

 
  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-9A-F]+")]]
    });
  }

  a:string;
  b:string;
  c:number;
  e:number;
  f:number;


  hexatobinary(hexaNumber:string){
    
    this.f=parseInt(hexaNumber, 16);
    this.a=(this.f).toString(2);
  }

}
