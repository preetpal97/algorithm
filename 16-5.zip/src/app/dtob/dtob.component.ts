import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-dtob',
  templateUrl: './dtob.component.html',
  styleUrls: ['./dtob.component.css']
})
export class DtobComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-9]+")]]
    });
  }
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;
  decimaltobinary(decimalNumber:string){
    this.u=parseInt(decimalNumber,10);  
    this.p=(this.u).toString(2);
  }



}
