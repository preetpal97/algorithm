import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-atob',
  templateUrl: './atob.component.html',
  styleUrls: ['./atob.component.css']
})
export class AtobComponent implements OnInit {
  dec:string
  ascii:string
  decimal:number
  binaryy:string
  warn :FormGroup ;
  constructor() { }
  
  ngOnInit() {
    
  }
  asciitobinary(ascii){
    this.dec=ascii.charCodeAt(0);
    this.decimal=parseInt(this.dec,10);
    this.binaryy=this.decimal.toString(2)
  }
}
