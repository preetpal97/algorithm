import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AtobComponent } from './atob.component';

describe('AtobComponent', () => {
  let component: AtobComponent;
  let fixture: ComponentFixture<AtobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AtobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AtobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
