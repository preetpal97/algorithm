import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PpmtopercentComponent } from './ppmtopercent.component';

describe('PpmtopercentComponent', () => {
  let component: PpmtopercentComponent;
  let fixture: ComponentFixture<PpmtopercentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PpmtopercentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PpmtopercentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
