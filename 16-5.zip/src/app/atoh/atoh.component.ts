import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-atoh',
  templateUrl: './atoh.component.html',
  styleUrls: ['./atoh.component.css']
})
export class AtohComponent implements OnInit {
dec:string
binary:string
h:any
hexa:any

  constructor() { }
  ngOnInit() {
  }
  asciitohexa(ascii){

     this.dec=ascii.charCodeAt(0);
     console.log(this.dec)
     this.binary=parseInt(this.dec).toString(2)
     this.h=parseInt(this.binary,2)
     this.hexa=(this.h).toString(16)
  }
}
