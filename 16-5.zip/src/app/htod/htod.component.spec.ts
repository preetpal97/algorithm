import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HtodComponent } from './htod.component';

describe('HtodComponent', () => {
  let component: HtodComponent;
  let fixture: ComponentFixture<HtodComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HtodComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HtodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
