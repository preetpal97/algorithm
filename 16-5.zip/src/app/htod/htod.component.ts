import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-htod',
  templateUrl: './htod.component.html',
  styleUrls: ['./htod.component.css']
})
export class HtodComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-9A-F]+")]]
    });
  }
  a:string;
  b:string;
  c:number;
  e:number;
  f:number;


  hexatodecimal(hexaNumber:string){
    this.c=parseInt(hexaNumber, 16);
  }


}
