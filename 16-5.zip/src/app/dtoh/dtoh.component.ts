import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-dtoh',
  templateUrl: './dtoh.component.html',
  styleUrls: ['./dtoh.component.css']
})
export class DtohComponent implements OnInit {

  warn :FormGroup ;
  constructor(private fb:FormBuilder) { }
  
  ngOnInit() {
    this.warn=this.fb.group({
      input:["",[Validators.pattern("[0-9]+")]]
    });
  }
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;

  decimaltohexa(decimalNumber:string){
    this.w=parseInt(decimalNumber,10);  
    this.r=(this.w).toString(16);
  }


}
