import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ppmtoppt',
  templateUrl: './ppmtoppt.component.html',
  styleUrls: ['./ppmtoppt.component.css']
})
export class PpmtopptComponent implements OnInit {
ppt:number;
  constructor() { }

  ngOnInit() {
  }
  ppmtoppt(PPMNumber:number)
  {
this.ppt=PPMNumber*1000000;
  }
}
