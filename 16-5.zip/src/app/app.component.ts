import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  ngOnInit(): void {
   this.input.valueChanges.subscribe(res=>console.log(res));
  }
  title = 'app';
  input=new FormControl;
  constructor(private router:Router){}
  tester(){
    // console.log(document.getElementById("myInput").innerHTML);
  console.log(this.input.value);
  if(this.input.value.toLowerCase()=='binary')
   this.router.navigate(['/update']);
  else if(this.input.value.toLowerCase()=='octal')
  this.router.navigate(['/update']);
  else if(this.input.value.toLowerCase()=='decimal')
  this.router.navigate(['/update']);
  else if(this.input.value.toLowerCase()=='hexadecimal')
  this.router.navigate(['/update']);
  else if(this.input.value.toLowerCase()=='ascii')
  this.router.navigate(['/update']);
  else if(this.input.value.toLowerCase()=='date to roman')
  this.router.navigate(['/roman']);
  else if(this.input.value.toLowerCase()=='date to roman')
  this.router.navigate(['/roman']);
  else if(this.input.value.toLowerCase()=='binary to hexa')
  this.router.navigate(['/btoh']);
  else if(this.input.value.toLowerCase()=='binary to ascii')
  this.router.navigate(['/btoa']);
  else if(this.input.value.toLowerCase()=='binary to decimal')
  this.router.navigate(['/btod']);
  else if(this.input.value.toLowerCase()=='binary to octal')
  this.router.navigate(['/btoo']);
  else if(this.input.value.toLowerCase()=='octal to decimal')
  this.router.navigate(['/otod']);
  else if(this.input.value.toLowerCase()=='octal to binary')
  this.router.navigate(['/otob']);
  else if(this.input.value.toLowerCase()=='octal to hexa')
  this.router.navigate(['/otoh']);
  else if(this.input.value.toLowerCase()=='hexa to binary')
  this.router.navigate(['/htob']);
  else if(this.input.value.toLowerCase()=='hexa to ascii')
  this.router.navigate(['/htoa']);
  else if(this.input.value.toLowerCase()=='hexa to decimal')
  this.router.navigate(['/htod']);
  else if(this.input.value.toLowerCase()=='decimal to binary')
  this.router.navigate(['/dtob']);
  else if(this.input.value.toLowerCase()=='decimal to octal')
  this.router.navigate(['/dtoo']);
  else if(this.input.value.toLowerCase()=='decimal to hexa')
  this.router.navigate(['/dtoh']);
  else if(this.input.value.toLowerCase()=='decimal to percent')
  this.router.navigate(['/dtop']);
  else if(this.input.value.toLowerCase()=='ascii to binary')
  this.router.navigate(['/atob']);
  else if(this.input.value.toLowerCase()=='ascii to hexa')
  this.router.navigate(['/atoh']);
  else if(this.input.value.toLowerCase()=='ppm')
  this.router.navigate(['/octal']);
  else if(this.input.value.toLowerCase()=='ppt')
  this.router.navigate(['/octal']);
  else if(this.input.value.toLowerCase()=='ppb')
  this.router.navigate(['/octal']);
  else if(this.input.value.toLowerCase()=='ppm to percent')
  this.router.navigate(['/ppmtopercent']);
  else if(this.input.value.toLowerCase()=='ppm to ppb')
  this.router.navigate(['/ppmtoppb']);
  else if(this.input.value.toLowerCase()=='ppm to ppt')
  this.router.navigate(['/ppmtoppt']);
  else if(this.input.value.toLowerCase()=='ppb to ppm')
  this.router.navigate(['/ppbtoppm']);
  else if(this.input.value.toLowerCase()=='ppt to ppm')
  this.router.navigate(['/ppttoppm']);
  else if(this.input.value.toLowerCase()=='roman')
  this.router.navigate(['/dateToRoman']);
  else if(this.input.value.toLowerCase()=='mathematical')
  this.router.navigate(['/math']);
  else if(this.input.value.toLowerCase()=='fraction')
  this.router.navigate(['/math']);
  else if(this.input.value.toLowerCase()=='percent')
  this.router.navigate(['/math']);
  else if(this.input.value.toLowerCase()=='fraction to percent')
  this.router.navigate(['/ftop']);
  else if(this.input.value.toLowerCase()=='fraction to decimal')
  this.router.navigate(['/ftod']);
  else if(this.input.value.toLowerCase()=='percent to ppm')
  this.router.navigate(['/ptop']);
  else if(this.input.value.toLowerCase()=='percent to fraction')
  this.router.navigate(['/ptof']);
  else if(this.input.value.toLowerCase()=='scientific')
  this.router.navigate(['/science']);
  else if(this.input.value.toLowerCase()=='length')
  this.router.navigate(['/science']);
  else if(this.input.value.toLowerCase()=='area')
  this.router.navigate(['/science']);
  else if(this.input.value.toLowerCase()=='volume')
  this.router.navigate(['/science']);
  else if(this.input.value.toLowerCase()=='length conversions')
  this.router.navigate(['/lc']);
  else if(this.input.value.toLowerCase()=='volume conversions')
  this.router.navigate(['/vc']);
  else if(this.input.value.toLowerCase()=='area conversions')
  this.router.navigate(['/ac']);
  }
}


