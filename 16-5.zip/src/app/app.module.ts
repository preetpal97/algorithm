import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AddComponent } from './add/add.component';
import { AppRoutingModule } from './app-routing.module';

import { OctalComponent } from './octal/octal.component';
import { BtohComponent } from './btoh/btoh.component';

import { BtoaComponent } from './btoa/btoa.component';
import { BtodComponent } from './btod/btod.component';
import { BtooComponent } from './btoo/btoo.component';

import { OtodComponent } from './otod/otod.component';

import { AtobComponent } from './atob/atob.component';
import { AtohComponent } from './atoh/atoh.component';

import { HtobComponent } from './htob/htob.component';
import { HtoaComponent } from './htoa/htoa.component';
import { HtodComponent } from './htod/htod.component';

import { DtobComponent } from './dtob/dtob.component';
import { DtooComponent } from './dtoo/dtoo.component';
import { DtohComponent } from './dtoh/dtoh.component';
import { DtopComponent } from './dtop/dtop.component';

import { PpmtopercentComponent } from './ppmtopercent/ppmtopercent.component';
import { PpmtoppbComponent } from './ppmtoppb/ppmtoppb.component';
import { PpmtopptComponent } from './ppmtoppt/ppmtoppt.component';
import { PpbtoppmComponent } from './ppbtoppm/ppbtoppm.component';
import { PpttoppmComponent } from './ppttoppm/ppttoppm.component';
import { ParallaxDirective } from './parallax.directive';
import { RomanComponent } from './roman/roman.component';
import { DtorComponent } from './dtor/dtor.component';
import { MathsComponent } from './maths/maths.component';
import { FractionComponent } from './fraction/fraction.component';
import { PercentComponent } from './percent/percent.component';
import { FtopComponent } from './ftop/ftop.component';
import { FtodComponent } from './ftod/ftod.component';
import { PtopComponent } from './ptop/ptop.component';
import { PtofComponent } from './ptof/ptof.component';
import { ScientificComponent } from './scientific/scientific.component';
import { LcComponent } from './lc/lc.component';
import { AcComponent } from './ac/ac.component';
import { VcComponent } from './vc/vc.component';
import { OtobComponent } from './otob/otob.component';
import { OtohComponent } from './otoh/otoh.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    AddComponent,
  
    OctalComponent,
    BtohComponent,
   
    BtoaComponent,
    BtodComponent,
    BtooComponent,
    
    OtodComponent,
   
    AtobComponent,
    AtohComponent,
  
    HtobComponent,
    HtoaComponent,
    HtodComponent,
  
    DtobComponent,
    DtooComponent,
    DtohComponent,
    DtopComponent,
  
   
   
    PpmtopercentComponent,
    PpmtoppbComponent,
    PpmtopptComponent,
    PpbtoppmComponent,
    PpttoppmComponent,
    ParallaxDirective,
    RomanComponent,
    DtorComponent,
    MathsComponent,
    FractionComponent,
    PercentComponent,
    FtopComponent,
    FtodComponent,
    PtopComponent,
    PtofComponent,
    ScientificComponent,
    LcComponent,
    AcComponent,
    VcComponent,
    OtobComponent,
    OtohComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
