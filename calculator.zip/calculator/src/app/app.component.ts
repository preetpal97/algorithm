import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'calculator';
  
    
//variable used for decimal to other conversion
  decimal: number;
  octal:string;
  hexa:string;
  d:number;
  h:number;

    
//variable used for hexa to other conversion
  a:string;
  b:string;
  c:number;
  e:number;
  f:number;

    
//variable used for octal to other conversion
  x:string;
  y:number;
  z:string;
  l:number;
  m:number;
  
//variable used for decimal to other conversion
  p:string;
  q:string;
  r:string;
  u:number;
  v:number;
  w:number;
  /*
  sum: number;
  calculate(first:number, second:number) {
   this.sum = +first + +second;
  }
  */
  
  binarytodecimal(binaryNumber:string){
    this.decimal=parseInt(binaryNumber, 2);
  }
  
  binarytooctal(binaryNumber:string){
    this.d=parseInt(binaryNumber, 2);
    this.octal=(this.d).toString(8);
  }
  binarytohexa(binaryNumber:string){
    this.h=parseInt(binaryNumber, 2);
    this.hexa=(this.h).toString(16);
  }
  hexatobinary(hexaNumber:string){
    this.f=parseInt(hexaNumber, 16);
    this.a=(this.f).toString(2);
  }
  hexatooctal(hexaNumber:string){
    this.e=parseInt(hexaNumber, 16);
    this.b=(this.e).toString(8);
  }
  hexatodecimal(hexaNumber:string){
    this.c=parseInt(hexaNumber, 16);
  }
  octaltobinary(octalNumber:string){
    this.l=parseInt(octalNumber, 8);
    this.x=(this.l).toString(2);
  }
  octaltodecimal(octalNumber:string){
    this.y=parseInt(octalNumber, 8);
  }
  octaltohexa(octalNumber:string){
    this.m=parseInt(octalNumber, 8);
    this.z=(this.m).toString(16);
  }
  decimaltobinary(decimalNumber:string){
    this.u=parseInt(decimalNumber,10);  
    this.p=(this.u).toString(2);
  }
  decimaltooctal(decimalNumber:string){
    this.v=parseInt(decimalNumber,10);  
    this.q=(this.v).toString(8);
  }
  decimaltohexa(decimalNumber:string){
    this.w=parseInt(decimalNumber,10);  
    this.r=(this.w).toString(16);
  } 
}
